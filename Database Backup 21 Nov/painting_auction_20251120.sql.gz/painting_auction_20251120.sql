--
-- PostgreSQL database dump
--

\restrict KgjFpVyxXIPdNJldYY5cnsQntLqr7HWJva4Ld87BqIB1lm2QhhGxebcbcnKZU0s

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: auction_admin
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO auction_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: auction_admin
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    email character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone
);


ALTER TABLE public.admins OWNER TO auction_admin;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: auction_admin
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO auction_admin;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auction_admin
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: auction_settings; Type: TABLE; Schema: public; Owner: auction_admin
--

CREATE TABLE public.auction_settings (
    id integer NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auction_settings OWNER TO auction_admin;

--
-- Name: auction_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: auction_admin
--

CREATE SEQUENCE public.auction_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auction_settings_id_seq OWNER TO auction_admin;

--
-- Name: auction_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auction_admin
--

ALTER SEQUENCE public.auction_settings_id_seq OWNED BY public.auction_settings.id;


--
-- Name: bids; Type: TABLE; Schema: public; Owner: auction_admin
--

CREATE TABLE public.bids (
    id integer NOT NULL,
    painting_id integer NOT NULL,
    user_id integer NOT NULL,
    bid_amount numeric(10,2) NOT NULL,
    bid_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    CONSTRAINT bid_amount_positive CHECK ((bid_amount > (0)::numeric)),
    CONSTRAINT bids_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'cancelled'::character varying, 'won'::character varying])::text[])))
);


ALTER TABLE public.bids OWNER TO auction_admin;

--
-- Name: bids_id_seq; Type: SEQUENCE; Schema: public; Owner: auction_admin
--

CREATE SEQUENCE public.bids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bids_id_seq OWNER TO auction_admin;

--
-- Name: bids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auction_admin
--

ALTER SEQUENCE public.bids_id_seq OWNED BY public.bids.id;


--
-- Name: paintings; Type: TABLE; Schema: public; Owner: auction_admin
--

CREATE TABLE public.paintings (
    id integer NOT NULL,
    artist_name character varying(200) NOT NULL,
    painting_name character varying(200) NOT NULL,
    image_url text,
    base_price numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    qr_code_data text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT paintings_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'sold'::character varying])::text[])))
);


ALTER TABLE public.paintings OWNER TO auction_admin;

--
-- Name: painting_current_bids; Type: VIEW; Schema: public; Owner: auction_admin
--

CREATE VIEW public.painting_current_bids AS
 SELECT p.id AS painting_id,
    p.artist_name,
    p.painting_name,
    p.base_price,
    p.image_url,
    p.status,
    COALESCE(max(b.bid_amount), p.base_price) AS current_price,
    count(b.id) AS total_bids
   FROM (public.paintings p
     LEFT JOIN public.bids b ON (((p.id = b.painting_id) AND ((b.status)::text = 'active'::text))))
  GROUP BY p.id, p.artist_name, p.painting_name, p.base_price, p.image_url, p.status;


ALTER TABLE public.painting_current_bids OWNER TO auction_admin;

--
-- Name: paintings_id_seq; Type: SEQUENCE; Schema: public; Owner: auction_admin
--

CREATE SEQUENCE public.paintings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paintings_id_seq OWNER TO auction_admin;

--
-- Name: paintings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auction_admin
--

ALTER SEQUENCE public.paintings_id_seq OWNED BY public.paintings.id;


--
-- Name: user_bid_rankings; Type: VIEW; Schema: public; Owner: auction_admin
--

CREATE VIEW public.user_bid_rankings AS
 SELECT b.id AS bid_id,
    b.painting_id,
    b.user_id,
    b.bid_amount,
    b.bid_time,
    rank() OVER (PARTITION BY b.painting_id ORDER BY b.bid_amount DESC, b.bid_time) AS rank
   FROM public.bids b
  WHERE ((b.status)::text = 'active'::text);


ALTER TABLE public.user_bid_rankings OWNER TO auction_admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: auction_admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    mobile character varying(15) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO auction_admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: auction_admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO auction_admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auction_admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: auction_settings id; Type: DEFAULT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.auction_settings ALTER COLUMN id SET DEFAULT nextval('public.auction_settings_id_seq'::regclass);


--
-- Name: bids id; Type: DEFAULT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.bids ALTER COLUMN id SET DEFAULT nextval('public.bids_id_seq'::regclass);


--
-- Name: paintings id; Type: DEFAULT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.paintings ALTER COLUMN id SET DEFAULT nextval('public.paintings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: auction_admin
--

COPY public.admins (id, username, password_hash, email, created_at, last_login) FROM stdin;
3	admin	$2b$10$F/ekY5jVjm9AyXrZ9IsZuO5b7JKbsAus9shJDM1psBWTiSybNhCJu	admin@college.edu	2025-11-18 06:10:25.836345	2025-11-20 14:59:37.516213
\.


--
-- Data for Name: auction_settings; Type: TABLE DATA; Schema: public; Owner: auction_admin
--

COPY public.auction_settings (id, start_date, end_date, is_active, created_at, updated_at) FROM stdin;
1	2025-11-18 05:40:16.334049	2025-12-18 05:40:16.334049	t	2025-11-18 05:40:16.334049	2025-11-18 05:40:16.334049
2	2025-11-18 06:04:42.269663	2025-12-18 06:04:42.269663	t	2025-11-18 06:04:42.269663	2025-11-18 06:04:42.269663
\.


--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: auction_admin
--

COPY public.bids (id, painting_id, user_id, bid_amount, bid_time, status) FROM stdin;
\.


--
-- Data for Name: paintings; Type: TABLE DATA; Schema: public; Owner: auction_admin
--

COPY public.paintings (id, artist_name, painting_name, image_url, base_price, status, qr_code_data, created_at, updated_at) FROM stdin;
23	Mayur Pandagale	Atal Setu in Rains	https://i.ibb.co/cczG6pj9/Atal-Setu-in-Rains-Mayur-Pandagale-15000.png	15000.00	active	PAINT1763626471268id769t1v7	2025-11-20 08:14:31.277942	2025-11-20 08:14:31.277942
24	Pushkar Pavaskar	Combate Naval de Iquique	https://i.ibb.co/PZrvBX9B/Combate-Naval-de-Iquique-Pushkar-Pavaskar-25000.png	25000.00	active	PAINT1763626536963gdhsxyxrr	2025-11-20 08:15:36.963736	2025-11-20 08:15:36.963736
25	Supriya Thite	Conquest of Srivijaya Empire	https://i.ibb.co/HDZJ993V/Conquest-of-Srivijaya-Empire-Supriya-Thite-20000.png	20000.00	active	PAINT1763626616042qbdu2478f	2025-11-20 08:16:56.053904	2025-11-20 08:16:56.053904
26	Parmeshwar Patekar	Harihar Fort	https://i.ibb.co/svS6c0rQ/Parmeshwar-Patekar-Harihar-Fort-15000.png	15000.00	active	PAINT17636266739329r7najgyu	2025-11-20 08:17:53.940963	2025-11-20 08:17:53.940963
27	Seema Patil	Prongs Light House	https://i.ibb.co/Q7Mc3Wwt/Prongs-Light-House-Seema-Patil-25000.png	25000.00	active	PAINT1763626734779rbzkm3ksz	2025-11-20 08:18:54.790685	2025-11-20 08:18:54.790685
28	Aniket Mhatre	Seige of Kottakal	https://i.ibb.co/RpVBWHKK/Seige-of-Kottakal-Aniket-Mhatre-20000.png	20000.00	active	PAINT1763626863437srgdf0rck	2025-11-20 08:21:03.447057	2025-11-20 08:21:03.447057
29	Vijay Jadhav	Shaniwar Wada	https://i.ibb.co/hxwcFsQf/Shaniwar-Wada-Vijay-Jadhav-15000.png	15000.00	active	PAINT1763626920584hz969ijgq	2025-11-20 08:22:00.595754	2025-11-20 08:22:00.595754
30	Seema Patil	Shree Nath Ji Venkateswar	https://i.ibb.co/ZZ4kRKV/Shree-Nath-Ji-Venkateshwar-Seema-Patil-30000.png	30000.00	active	PAINT17636269672158nvcu6avh	2025-11-20 08:22:47.224985	2025-11-20 08:22:47.224985
31	Mayur Pandagale	The Siege of Malaka	https://i.ibb.co/KcNDFPCJ/The-siege-of-Malaka-Mayur-Pandagale-15000.png	15000.00	active	PAINT176362702931882tjqcu48	2025-11-20 08:23:49.32769	2025-11-20 08:23:49.32769
32	Supriya Thite	Tikona Fort	https://i.ibb.co/fGDQ4CbS/Tikona-Fort-Supriya-Thite-30000.png	30000.00	active	PAINT1763627089941z0z8h4k5u	2025-11-20 08:24:49.950671	2025-11-20 08:24:49.950671
33	Renzy Mudliyar	Trading Port of Zamorin	https://i.ibb.co/bgc8DDN5/Trading-Port-of-Zamorin-Renzy-Mudliyar-30000.png	30000.00	active	PAINT1763627162400p3gw7x8ru	2025-11-20 08:26:02.411092	2025-11-20 08:26:02.411092
34	Riya Mudaliar	Travancore Dutch War	https://i.ibb.co/WvMjTs1T/Travancore-Dutch-War-Riya-Mudaliar-25000.png	25000.00	active	PAINT1763627219359uywsg1gb3	2025-11-20 08:26:59.369515	2025-11-20 08:26:59.369515
35	Vijay Jadhav	Victory Parade at London	https://i.ibb.co/jv98CD93/Victory-Parade-at-London-Vijay-Jadhav-6000.png	6000.00	active	PAINT1763627279209r3dw14oa9	2025-11-20 08:27:59.218741	2025-11-20 08:27:59.218741
36	Pushkar Pavaskar	Vijay Durg Fort	https://i.ibb.co/pvfMzv5F/Vijay-Durg-Fort-Pushkar-Pavaskar-25000.png	25000.00	active	PAINT1763627332232zp6dmkqcn	2025-11-20 08:28:52.241739	2025-11-20 08:28:52.241739
37	Vilas Ambule	Antique map of Ceylon	https://i.ibb.co/DDvKNZyL/Antique-map-of-Ceylon-Vilas-Ambule-30000.png	30000.00	active	PAINT1763627387306dfdr39j3z	2025-11-20 08:29:47.38758	2025-11-20 08:29:47.38758
38	Pushkar Pavaskar	A Beacon Light House	https://i.ibb.co/fz34HyjW/A-Beacon-Light-House-Pushkar-Pavaskar-30000.png	30000.00	active	PAINT17636279636182genx9sun	2025-11-20 08:39:23.627335	2025-11-20 08:39:23.627335
39	Supriya Thite	A Floating Market Supriya	https://i.ibb.co/w1BcXhF/A-Floating-Market-Supriya-Thite-25000.png	25000.00	active	PAINT17636280183109p1huojta	2025-11-20 08:40:18.320991	2025-11-20 08:40:18.320991
40	Renzy Mudaliar	A scroll of Ancient Ships	https://i.ibb.co/bM5YRXzp/A-scroll-of-Ancient-Ships-Renzy-Mudaliar-30000.png	30000.00	active	PAINT17636280876151ok6fpmo1	2025-11-20 08:41:27.624898	2025-11-20 08:41:27.624898
41	Satish Wavare	Aircraft Carrier Dock in Rains	https://i.ibb.co/kV5NwXzV/Aircraft-Carrier-Dock-in-Rains-Satish-Wavare-30000.png	30000.00	active	PAINT1763628171428fo94el3w5	2025-11-20 08:42:51.437544	2025-11-20 08:42:51.437544
42	Satish Wavare	Aircraft Carrier	https://i.ibb.co/1J06rPFm/Aircraft-Carrier-Satish-Wavare-35000.png	35000.00	active	PAINT1763628278120luk2wwc8f	2025-11-20 08:44:38.130386	2025-11-20 08:44:38.130386
44	Riya Mudaliar	Battle of Lade	https://i.ibb.co/G4fRgCcR/Battle-of-Lade-Riya-Mudaliar-25000.png	25000.00	active	PAINT1763628656646euq9bx0d1	2025-11-20 08:50:56.655859	2025-11-20 08:50:56.655859
45	Parmeshwar Patekar	Beached Ship	https://i.ibb.co/wrwg2Fxq/Beached-Ship-Parmeshwar-Patekar-20000.png	20000.00	active	PAINT17636287596557w780bfwh	2025-11-20 08:52:39.655697	2025-11-20 08:52:39.655697
46	Supriya Thite	Borobudur-Ship	https://i.ibb.co/b5k0JmTT/Borobudur-Ship-Supriya-Thite-35000.png	35000.00	active	PAINT1763629000463v1irfxd61	2025-11-20 08:56:40.472504	2025-11-20 08:56:40.472504
47	Mayur Pandagale	Celeberrimvm India Emporivm	https://i.ibb.co/zVZygvLL/Celeberrimvm-India-Emporivm-Mayur-Pandagale-15000.png	15000.00	active	PAINT176362909116069xc6tm9m	2025-11-20 08:58:11.160349	2025-11-20 08:58:11.160349
48	Satish-Wavare	CG Dock Vintage	https://i.ibb.co/3GP2Byj/CG-Dock-Vintage-Satish-Wavare-25000.png"	25000.00	active	PAINT17636291471893jxun2zgx	2025-11-20 08:59:07.199866	2025-11-20 08:59:07.199866
49	Vilas Rajput	Chattar Manzil	https://i.ibb.co/8nmv9ww3/Chattar-Manzil-Vilas-Rajput-20000.png	20000.00	active	PAINT1763629209563mo6vkq8nf	2025-11-20 09:00:09.57426	2025-11-20 09:00:09.57426
50	Nitin Tirpude	Crimson Tides	https://i.ibb.co/JR9WkZB2/Crimson-Tides-Nitin-Tirpude-20000.png	20000.00	active	PAINT1763629255371p31z1jjlz	2025-11-20 09:00:55.380672	2025-11-20 09:00:55.380672
51	Renzy Mudaliar	Dumra Departing	https://i.ibb.co/twZrg5rg/Dumra-Departing-Bombay-Renzy-Mudaliar-35000.png	35000.00	active	PAINT1763629302764vp738hbgd	2025-11-20 09:01:42.774331	2025-11-20 09:01:42.774331
52	Mahesh Gite	Dutch on Shores	https://i.ibb.co/v0rF7k7/Dutch-on-Shores-Mahesh-Gite-20000.png	20000.00	active	PAINT176362934734809djq397b	2025-11-20 09:02:27.348958	2025-11-20 09:02:27.348958
53	Seema Patil	Dutch Sail Ship	https://i.ibb.co/hRPf972P/Dutch-Sail-Ship-Seema-Patil-20000.png	20000.00	active	PAINT1763629418677zue6h65hg	2025-11-20 09:03:38.678385	2025-11-20 09:03:38.678385
55	Parmeshwar Pawskar	Esplanade Calcutta	https://i.ibb.co/KctFvfj6/Esplanade-Calcutta-Parmeshwar-Pawskar-20000.png	20000.00	active	PAINT1763629905691mzydlapj1	2025-11-20 09:11:45.701512	2025-11-20 09:11:45.701512
56	Renzy Mudaliar	Flora Fountain	https://i.ibb.co/hF7qTgpL/Flora-Fountain-Renzy-Mudaliar-35000.png	35000.00	active	PAINT17636300080803ssobbkzq	2025-11-20 09:13:28.092296	2025-11-20 09:13:28.092296
57	Mayur Pandagale	Fort of Bombay 1668	https://i.ibb.co/bRPDDj16/Fort-of-Bombay-1668-Mayur-Pandagale-15000.png	15000.00	active	PAINT1763630099428ai3170od1	2025-11-20 09:14:59.428523	2025-11-20 09:14:59.428523
58	Pushkar-Pavaskar	Fort of Bombay-1668	https://i.ibb.co/C3SzBC6L/Fort-of-Bombay-1668-Pushkar-Pavaskar-20000.png	20000.00	active	PAINT1763630455970qyti3h7wp	2025-11-20 09:20:55.970821	2025-11-20 09:20:55.970821
60	Vilas Rajput	Foudroyant 1817	https://i.ibb.co/s9h5rPW8/Foudroyant-1817-Vilas-Rajput-20000.png	20000.00	active	PAINT1763633817167pq3kxs1y9	2025-11-20 10:16:57.176155	2025-11-20 10:16:57.176155
61	Mahesh Gite	Gateway of India	https://i.ibb.co/LDDzq2qk/Gateway-of-India-Mahesh-Gite-20000.png	20000.00	active	PAINT1763633864873a9vmyrj4j	2025-11-20 10:17:44.883983	2025-11-20 10:17:44.883983
63	Satish Wavare	Guard of Honour	https://i.ibb.co/x8195Cpw/Guard-of-Honour-Satish-Wavare-25000.png	25000.00	active	PAINT1763634236687ihvwz5w1d	2025-11-20 10:23:56.699733	2025-11-20 10:23:56.699733
65	Nitin Tirpude	Indus Valley	https://i.ibb.co/RTM4cxLQ/Indus-Valley-Nitin-Tirpude-30000.png	30000.00	active	PAINT17636346320834bl0thjpp	2025-11-20 10:30:32.09272	2025-11-20 10:30:32.09272
67	Seema Patil	Kamdhenu	https://i.ibb.co/677mhrbj/Kamdhenu-Seema-Patil-30000.png	30000.00	active	PAINT1763634771947z3ktrfd5n	2025-11-20 10:32:51.956814	2025-11-20 10:32:51.956814
68	Mahesh Naga	Marine drive Mumbai	https://i.ibb.co/Mych56Cr/Marine-drive-Mumbai-Mahesh-Naga-15000.png	15000.00	active	PAINT1763634818684fphhadutc	2025-11-20 10:33:38.698668	2025-11-20 10:33:38.698668
69	Vilas-Rajput	Martha Warship Galbat or Gallivat Vilas	https://i.ibb.co/nMFMtjzP/Martha-Warship-Galbat-or-Gallivat-Vilas-Rajput-15000.png	15000.00	active	PAINT17636348795586oohh9dz8	2025-11-20 10:34:39.56672	2025-11-20 10:34:39.56672
70	Supriya Thite	Mhadei at INS Mandovi	https://i.ibb.co/KpFvNmxM/Mhadei-at-INS-Mandovi-Supriya-Thite-30000.png	30000.00	active	PAINT1763634940647djx41ipsg	2025-11-20 10:35:40.656873	2025-11-20 10:35:40.656873
71	Renzy Mudaliar	Misticque French sail Ship	https://i.ibb.co/zT5PJPGQ/Misticque-French-sail-Ship-Renzy-Mudaliar-20000.png	20000.00	active	PAINT17636349908540figsenf5	2025-11-20 10:36:30.8642	2025-11-20 10:36:30.8642
72	Mahesh Naga	Mughal Empire	https://i.ibb.co/ksNLRLnb/Mughal-Empire-Mahesh-Naga-30000.png	30000.00	active	PAINT17636350599117l11ze8kj	2025-11-20 10:37:39.922299	2025-11-20 10:37:39.922299
73	Vilas Ambole	Mumbai Melange	https://i.ibb.co/C5gTNpyb/Mumbai-Melange-Vilas-Ambole-30000.png	30000.00	active	PAINT1763635117423636gzpt9r	2025-11-20 10:38:37.423884	2025-11-20 10:38:37.423884
74	Satish Wavare	President s Colour	https://i.ibb.co/jvRMwPk7/President-s-Colour-Satish-Wavare-35000.png	35000.00	active	PAINT1763635236673uyfudbtcx	2025-11-20 10:40:36.685691	2025-11-20 10:40:36.685691
75	Vijay-Jadhav	Rajgadh Fort	https://i.ibb.co/4RWsWkm7/Rajgadh-Fort-Vijay-Jadhav-15000.png	15000.00	active	PAINT1763635276162oe6dgev9y	2025-11-20 10:41:16.171064	2025-11-20 10:41:16.171064
77	Mangesh Ronghe	Rajula at Madras	https://i.ibb.co/zhHmnR1Z/Rajula-at-Madras-Mangesh-Ronghe-15000.png	15000.00	active	PAINT1763635375026dgyen6psg	2025-11-20 10:42:55.02715	2025-11-20 10:42:55.02715
78	Aniket Mhatre	Ram Setu	https://i.ibb.co/nq5PyPR8/Ram-Setu-Aniket-Mhatre-20000.png	20000.00	active	PAINT17636354095818kcaxazpb	2025-11-20 10:43:29.592577	2025-11-20 10:43:29.592577
79	Mahesh Gite	Riviola	https://i.ibb.co/Txyn6j1G/Riviola-Mahesh-Gite-20000.png	20000.00	active	PAINT17636354450537h6uenp3m	2025-11-20 10:44:05.062276	2025-11-20 10:44:05.062276
80	Riya Mudliyar	Stone Bridge on Gomti River	https://i.ibb.co/pgp9XwB/Stone-Bridge-on-Gomti-River-Riya-Mudliyar-25000.png	25000.00	active	PAINT17636355746248qmkucakm	2025-11-20 10:46:14.633859	2025-11-20 10:46:14.633859
81	Riya Mudaliar	Stone Carving	https://i.ibb.co/B2Dyp6N4/Stone-Carving-Riya-Mudaliar-30000.png	30000.00	active	PAINT1763635630597x0qw295kz	2025-11-20 10:47:10.608963	2025-11-20 10:47:10.608963
82	Renzy Mudaliar	The mighty Vikrant	https://i.ibb.co/JjpHYL98/The-mighty-Vikrant-Renzy-Mudaliar-2000.png	2000.00	active	PAINT17636358843334hst5idcp	2025-11-20 10:51:24.342739	2025-11-20 10:51:24.342739
83	Riya Mudaliar	The Vajra of Cholas	https://i.ibb.co/B22qdhDf/The-Vajra-of-Cholas-Riya-Mudaliar-25000.png	25000.00	active	PAINT1763635931456vg9vcpwcg	2025-11-20 10:52:11.466001	2025-11-20 10:52:11.466001
84	Vijay Jadhav	The-Waves	https://i.ibb.co/5PX98kL/The-Waves-Vijay-Jadhav-20000.png	20000.00	active	PAINT1763636071780klph8jb36	2025-11-20 10:54:31.790136	2025-11-20 10:54:31.790136
85	Satish Wavare	Tiger	https://i.ibb.co/zHW7xz9t/Tiger-Satish-Wavare-25000.png	25000.00	active	PAINT1763636113905wsewnvqno	2025-11-20 10:55:13.915224	2025-11-20 10:55:13.915224
86	Mahesh Naga	Vasco-Da-Gama-in-India	https://i.ibb.co/cSJLwHQx/Vasco-Da-Gama-in-India-Mahesh-Naga-35000.png	35000.00	active	PAINT1763636169516nw3ls8ane	2025-11-20 10:56:09.525438	2025-11-20 10:56:09.525438
87	Parmeshwar Patekar	Vijaya in Ceylon	https://i.ibb.co/Gv8MZz88/Vijaya-in-Ceylon-Parmeshwar-Patekar-15000.png	15000.00	active	PAINT1763636213446dpqujxkfq	2025-11-20 10:56:53.456534	2025-11-20 10:56:53.456534
88	Renzy-Mudaliar	Zamorin	https://i.ibb.co/SS49T0X/Zamorin-Renzy-Mudaliar-35000.png	35000.00	active	PAINT176363624857337u2dyan9	2025-11-20 10:57:28.585885	2025-11-20 10:57:28.585885
89	Vilas Ambule	A Maritime silk route tapestry	https://i.ibb.co/TMRtYJkZ/A-Maritime-silk-route-tapestry-Vilas-Ambule-30000.png	30000.00	active	PAINT17636370180155z0qcpbig	2025-11-20 11:10:18.015855	2025-11-20 11:10:18.015855
90	Parmeshwar Patekar	Ancient ship in Dry Dock	https://i.ibb.co/fLnhb3h/Ancient-ship-in-Dry-Dock-Parmeshwar-Patekar-20000.png	20000.00	active	PAINT1763637084224wx55kes1c	2025-11-20 11:11:24.225063	2025-11-20 11:11:24.225063
91	Vilas-Rajput	Maratha ship	https://i.ibb.co/zhB8SVy9/Maratha-ship-Vilas-Rajput-20000.png	20000.00	active	PAINT1763637138480e8l8wmxz8	2025-11-20 11:12:18.480687	2025-11-20 11:12:18.480687
92	Nitin Tirpude	Portolan Charts	https://i.ibb.co/NgFtdnr9/Portolan-Charts-Nitin-Tirpude-20000.png	20000.00	active	PAINT17636371965844rmndkast	2025-11-20 11:13:16.596856	2025-11-20 11:13:16.596856
93	Mangesh Ronghe	Kala Ghoda Lion Gate	https://i.ibb.co/twXR25hz/Kala-Ghoda-Lion-Gate-Mangesh-Ronghe-15000.png	15000.00	active	PAINT176364086759057zl9n9st	2025-11-20 12:14:27.601488	2025-11-20 12:14:27.601488
94	Mayur Pandagale	Gurab A Martha Warship	https://i.ibb.co/2YWfdGnb/Gurab-A-Martha-Warship-Mayur-Pandagale-15000.png	15000.00	active	PAINT17636410307981ubjozp30	2025-11-20 12:17:10.808413	2025-11-20 12:17:10.808413
95	Vilas Rajput	Great Eastern	https://i.ibb.co/kVNksbtM/Great-Eastern-Vilas-Rajput-15000.png	15000.00	active	PAINT1763641132007fphnhhlez	2025-11-20 12:18:52.021634	2025-11-20 12:18:52.021634
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: auction_admin
--

COPY public.users (id, first_name, last_name, mobile, password_hash, created_at, updated_at) FROM stdin;
1	Rajith	Ps	9821751191	$2b$10$qbKhfvE83F5j0t54Vk/Aw.23VagGSm.RhNIVBJHvDCky3WRX4DeBK	2025-11-18 06:56:20.588852	2025-11-18 06:56:20.588852
2	Shubham	Mehta	9868467557	$2b$10$iGXcANjKzgYnOXD6wh6eTuU2PzBexYzXMCvBOSk7mcPAB1dQkjmVi	2025-11-19 03:45:20.025334	2025-11-19 03:45:20.025334
3	Gautam	Gautam	9821751192	$2b$10$Nhf50vWFlMe1I9Et0AfN1OTLtHH0yJLjuSbLfclGnSKeRETOcDzgC	2025-11-19 10:39:36.233858	2025-11-19 10:39:36.233858
4	Gautam	Gautam	9324816664	$2b$10$TEDf36DegKcnTXfLGYfqSuoYacHxmk90eStcIqzdvZzWQiWoKlGCG	2025-11-20 03:49:32.319428	2025-11-20 03:49:32.319428
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auction_admin
--

SELECT pg_catalog.setval('public.admins_id_seq', 3, true);


--
-- Name: auction_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auction_admin
--

SELECT pg_catalog.setval('public.auction_settings_id_seq', 2, true);


--
-- Name: bids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auction_admin
--

SELECT pg_catalog.setval('public.bids_id_seq', 9, true);


--
-- Name: paintings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auction_admin
--

SELECT pg_catalog.setval('public.paintings_id_seq', 95, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auction_admin
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: auction_settings auction_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.auction_settings
    ADD CONSTRAINT auction_settings_pkey PRIMARY KEY (id);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (id);


--
-- Name: paintings paintings_pkey; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.paintings
    ADD CONSTRAINT paintings_pkey PRIMARY KEY (id);


--
-- Name: paintings paintings_qr_code_data_key; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.paintings
    ADD CONSTRAINT paintings_qr_code_data_key UNIQUE (qr_code_data);


--
-- Name: users users_mobile_key; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_key UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_bids_amount; Type: INDEX; Schema: public; Owner: auction_admin
--

CREATE INDEX idx_bids_amount ON public.bids USING btree (bid_amount DESC);


--
-- Name: idx_bids_painting_id; Type: INDEX; Schema: public; Owner: auction_admin
--

CREATE INDEX idx_bids_painting_id ON public.bids USING btree (painting_id);


--
-- Name: idx_bids_user_id; Type: INDEX; Schema: public; Owner: auction_admin
--

CREATE INDEX idx_bids_user_id ON public.bids USING btree (user_id);


--
-- Name: idx_paintings_status; Type: INDEX; Schema: public; Owner: auction_admin
--

CREATE INDEX idx_paintings_status ON public.paintings USING btree (status);


--
-- Name: idx_users_mobile; Type: INDEX; Schema: public; Owner: auction_admin
--

CREATE INDEX idx_users_mobile ON public.users USING btree (mobile);


--
-- Name: auction_settings update_auction_settings_updated_at; Type: TRIGGER; Schema: public; Owner: auction_admin
--

CREATE TRIGGER update_auction_settings_updated_at BEFORE UPDATE ON public.auction_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: paintings update_paintings_updated_at; Type: TRIGGER; Schema: public; Owner: auction_admin
--

CREATE TRIGGER update_paintings_updated_at BEFORE UPDATE ON public.paintings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: auction_admin
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bids bids_painting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_painting_id_fkey FOREIGN KEY (painting_id) REFERENCES public.paintings(id) ON DELETE CASCADE;


--
-- Name: bids bids_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auction_admin
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict KgjFpVyxXIPdNJldYY5cnsQntLqr7HWJva4Ld87BqIB1lm2QhhGxebcbcnKZU0s

